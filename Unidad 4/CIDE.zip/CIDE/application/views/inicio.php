<!DOCTYPE html>
<html>
<title>HTML Tutorial</title>
<body>

<h1>Página Principal</h1>
<img src="">

</body>
</html>